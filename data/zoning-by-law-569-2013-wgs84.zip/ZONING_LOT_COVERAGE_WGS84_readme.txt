ZONING_LOT_COVERAGE_WGS84_readme
 

Column name  (Description)
======================================
OBJECTID = OBJECTID  (Unique system identifier)
PRCNT_CVER = ZN_COVERAGE  (Percent lot area covered by buildings)
