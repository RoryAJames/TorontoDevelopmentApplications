ZONING_POLICY_AREA_WGS84_readme
 

Column name  (Description)
======================================
OBJECTID = OBJECTID  (Unique system identifier)
POLICY_ID = POLICY_AREA  (Policy Area ID)
ZN_EXCPTN = ZN_EXCPTN  ((x2345))
EXCEPTN_ID = ZN_EXCPTN_NO  ((x2345) must be used with Zone Reference)
CHAPT_200 = LINK_TO_PARKINGRATE  (Chapter 200 Parking)
EXCEPTN_LK = LINK_TO_EXCPTN  ((x2345))
