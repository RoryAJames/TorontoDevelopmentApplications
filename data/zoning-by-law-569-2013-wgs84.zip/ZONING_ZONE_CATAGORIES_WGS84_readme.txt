ZONING_ZONE_CATAGORIES_WGS84_readme
 

Column name  (Description)
======================================
OBJECTID = OBJECTID  (Unique system identifier)
GEN_ZONE
 = ZN_LU_CATEGORY  (Type of Zone
)
ZN_ZONE = ZN_ZONE  (Specific Zone
)
ZN_HOLDING = ZN_HOLDING
HOLDING_ID = ZN_HOLDING_NO  (Holding By-law ID
)
FRONTAGE = ZN_FRONTAGE  (Minimum Lot Frontage
)
ZN_AREA = ZN_AREA
UNITS
 = ZN_UNIT_COUNT  (Number of dwelling units permitted
)
DENSITY = ZN_FSI_DENSITY  (Ratio of building floor area to lot area)
COVERAGE = ZN_COVERAGE  (Percent of lot covered by buildings)
FSI_TOTAL = FSI_TOTAL
PRCNT_COMM = FSI_COMMERCIAL_USE  (Percent Commercial floor area)
PRCNT_RES = FSI_RESIDENTIAL_USE  (Percent Residential floor area)
PRCNT_EMMP = FSI_EMPLOYMENT_USE  (Percent employment floor area)
PRCNT_OFFC = FSI_OFFICE_USE  (Percent office floor area
)
ZN_EXCPTN = ZN_EXCPTN
EXCEPTN_NO = ZN_EXCPTN_NO  (Exception ID
)
STAND_SET = STANDARDS_SET  (Deveklopment Standard ID for Commercial
)
ZN_STATUS = ZN_STATUS
ZN_STRING = ZN_STRING
AREA_UNITS = ZN_AREA_UNIT  (Area Units
)
ZBL_CHAPTR = ZBL_CHAPTER  (Reference to Chapter)
ZBL_SECTN = ZBL_SECTION  (Reference to Section)
ZBL_EXCPTN = ZBL_EXCPTN  (Reference to Exception)
