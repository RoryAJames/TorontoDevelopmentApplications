ZONING_ROOMING_HOUSE_WGS84_readme
 

Column name  (Description)
======================================
OBJECTID = OBJECTID  (Unique system identifier)
RMH_AREA = RMG_HS_AREA  (B
)
RMG_HS_NO = RMG_HS_NO  (3)
RMG_STRING = RMG_STRING  (B-3)
CHAP150_25 = BYLAW_SECTIONLINK
