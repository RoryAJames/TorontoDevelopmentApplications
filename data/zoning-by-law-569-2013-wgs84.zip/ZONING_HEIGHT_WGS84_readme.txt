ZONING_HEIGHT_WGS84_readme
 

Column name  (Description)
======================================
OBJECTID = OBJECTID  (Unique system identifier)
HT_HEIGHT = HT_HEIGHT  (Maximum Height Metres)
HT_STORIES = HT_STORIES  (Maximum Storeys)
HT_STRING = HT_STRING  (Height and Storey Label)
